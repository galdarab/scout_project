
public class Main {
    public static void main(String[] args) {
        MilanTeam milanTeam = new MilanTeam();

        // הוספת שחקנים לקבוצת מילאן
        milanTeam.addPlayer(new EnglishPlayer("John terry", 25, "Defender"));
        milanTeam.addPlayer(new FranchPlayer("Zinadin henry", 28, "Midfielder"));
        milanTeam.addPlayer(new IsraeliPlayer("Eran zehavi", 30, "Forward"));
        milanTeam.addPlayer(new SpanishPlayer("David villa", 27, "Forward"));
        milanTeam.addPlayer(new GermanPlayer("Thomas Müller", 24, "Midfielder"));

        // הדפסת מספר השחקנים בקבוצת מילאן
        milanTeam.numberOfPlayers();
    }
}