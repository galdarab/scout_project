public class Player { // המחלקה ממנה כל השחקנים יורשים
    protected String name;
    protected int age;
    protected String position;
    protected String exTeam;

    public Player(String name, int age, String position, String exTeam) {
        this.name = name;
        this.age = age;
        this.position = position;
        this.exTeam = exTeam;
    }
    public String getName() {
        return name;
    }
    public int getAge() {
        return age;
    }
    public String getPosition() {
        return position;
    }



    public String getExTeam() {
        return exTeam;
    }

    public void setExTeam(String exTeam) {
        this.exTeam = exTeam;
    }

    // Override toString הדפסת הנתונים של השחקן
    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", age=" + age +
                ", position='" + position + '\'' +
                ", localLeague='" + exTeam + '\'' +
                '}';
    }
}