public class IsraeliPlayer extends Player {// השחקן הישראלי
    public IsraeliPlayer(String name, int age, String position) {//הורשה
        super(name, age, position, "Maccabi tel-aviv, ");
    }

    // Getter and setter methods לקבוצה לשעבר
    public String getExTeam() {
        return exTeam;
    }

    public void setExTeam(String localLeague) {
        this.exTeam = exTeam;
    }
}