public class EnglishPlayer extends Player { // השחקן האנגלי
    public EnglishPlayer(String name, int age, String position) {
        super(name, age, position, "man-city, ");
    }

    // Getter and setter methods של הקבוצה הקודמת
    public String getExTeam() {
        return exTeam;
    }

    public void setExTeam(String exTeam) {
        this.exTeam = exTeam;
    }
}