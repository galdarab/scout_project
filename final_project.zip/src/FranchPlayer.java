public class FranchPlayer extends Player { //השחקן הצרפתי
    public FranchPlayer(String name, int age, String position) {//הורשה מ-player
        super(name, age, position, "Monaco, ");
    }

    // Getter and setter methods לקבוצה הקודמת
    public String getExTeam() {
        return exTeam;
    }

    public void setExTeam(String localLeague) {
        this.exTeam = localLeague;
    }
}