import java.util.ArrayList;
import java.util.List;
public class MilanTeam { //המחלקה בה בניתי את הקבוצה שאליה צירפתי שחקנים
    private List<Player> milan = new ArrayList<>();

    // מספר השחקנים בקבוצת מילאן והדפסת שמות כל השחקנים
    public void numberOfPlayers() {
        System.out.println("The number of players who joined Milan this summer is: " + milan.size());
        System.out.println("the details of the players: ");
        for (Player player : milan) { //לולאה שמדפיסה לתוכנית את כל פרטי השחקנים שהצטרפו
            System.out.println("name: " + player.getName() + ", ex-team: " + player.getExTeam() +"age: "+player.getAge()+ ", position: " + player.getPosition());
        }
    }

    // הוספת שחקן לקבוצת מילאן
    public void addPlayer(Player player) { //פונקציה להוספת שחקנים
        milan.add(player);
    }
}