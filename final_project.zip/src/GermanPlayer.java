public class GermanPlayer extends Player { // השחקן הגרמני
    public GermanPlayer(String name, int age, String position) {//הורשה
        super(name, age, position, "Bayern munich, ");
    }

    // Getter and setter methods לקוצה הקודמת
    public String getExTeam() {
        return exTeam;
    }

    public void setExTeam(String exTeam) {
        this.exTeam = exTeam;
    }
}