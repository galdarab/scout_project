public class SpanishPlayer extends Player { // השחקן הספרדי
    public SpanishPlayer(String name, int age, String position) { // הורשה מ-player
        super(name, age, position, "Barcelona, ");
    }

    // Getter and setter לקבוצה הקודמת
    public String getLocalLeague() {
        return exTeam;
    }

    public void setLocalLeague(String localLeague) {
        this.exTeam = exTeam;
    }
}